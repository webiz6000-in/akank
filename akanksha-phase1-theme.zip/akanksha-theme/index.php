<?php get_header(); ?>
<main class="max-w-7xl mx-auto px-6 py-16">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article <?php post_class(); ?>>
<?php the_title('<h1>', '</h1>'); ?>
<div><?php the_content(); ?></div>
</article>
<?php endwhile; else : ?><p><?php esc_html_e('Nothing found.', 'akanksha'); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>
