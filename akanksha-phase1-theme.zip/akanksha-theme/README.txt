AKANKSHA EDUCATIONAL FOUNDATION – CUSTOM WORDPRESS THEME
Version: 0.1.0 (Phase 1 foundation)

INSTALLATION
1. Back up the WordPress site and database.
2. Copy the akanksha-theme folder into wp-content/themes/.
3. In WordPress Admin, go to Appearance > Themes and activate “Akanksha Educational Foundation”.
4. Create WordPress Pages with these slugs:
   about, what-we-do, activities-and-initiatives, updates, gallery, faqs, contact, donate
5. Set the Home page under Settings > Reading to a static page and select the page whose slug is the site's front page (or configure the front page in the next development step).
6. Set permalinks to Post name under Settings > Permalinks.

IMPORTANT
- This is the Phase 1 theme foundation, not the completed dynamic website.
- Updates, Single Update and FAQ pages currently render the supplied static HTML as a conversion baseline. Their dynamic WordPress content workflows are planned for later phases.
- The supplied HTML markup is retained; local assets are loaded from this theme.
- Do not activate on a production site without a backup and staging verification.
