/* ==========================
   Mobile Navigation
========================== */
const menuBtn = document.getElementById("menuBtn");
const mobileMenu = document.getElementById("mobileMenu");

if (menuBtn && mobileMenu) {
    menuBtn.addEventListener("click", () => {
        mobileMenu.classList.toggle("hidden");
    });
}

/* ==========================
   Counter Animation (Fixed)
========================== */
const counters = document.querySelectorAll(".counter");

const runCounter = (counter) => {
    const target = +counter.getAttribute("data-target");
    let count = 0;
    
    // Adjust speed divider based on your target size
    const increment = target / 50; 

    const updateCount = () => {
        count += increment;
        if (count < target) {
            counter.innerText = Math.ceil(count);
            setTimeout(updateCount, 30);
        } else {
            counter.innerText = target + "+";
        }
    };

    updateCount();
};

// Intersection Observer for Counters
const counterObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            runCounter(entry.target);
            observer.unobserve(entry.target); // Run only once
        }
    });
}, { threshold: 0.3 });

counters.forEach(counter => {
    counterObserver.observe(counter);
});

/* ==========================
   Fade In Animation (Safe)
========================== */
const sections = document.querySelectorAll("section");

const sectionObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.1 });

sections.forEach(sec => {
    // Only apply initial hidden state via JS to prevent layout bugs if JS fails
    sec.classList.add("js-fade-section");
    sectionObserver.observe(sec);
});

/* ==========================
   FAQ Accordion
   Local-only: no external JS/CSS required
========================== */
const faqButtons = document.querySelectorAll(".faq-btn");

faqButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const item = button.closest(".faq-item");
        const content = item ? item.querySelector(".faq-content") : null;
        const icon = item ? item.querySelector(".faq-icon") : null;

        if (!item || !content) return;

        const isOpen = item.classList.contains("faq-open");

        // Close other open questions so the page stays compact.
        document.querySelectorAll(".faq-item.faq-open").forEach((openItem) => {
            if (openItem === item) return;
            openItem.classList.remove("faq-open");
            const openButton = openItem.querySelector(".faq-btn");
            const openContent = openItem.querySelector(".faq-content");
            const openIcon = openItem.querySelector(".faq-icon");
            if (openButton) openButton.setAttribute("aria-expanded", "false");
            if (openContent) {
                openContent.hidden = true;
                openContent.style.maxHeight = "";
            }
            if (openIcon) openIcon.textContent = "+";
        });

        if (isOpen) {
            item.classList.remove("faq-open");
            button.setAttribute("aria-expanded", "false");
            content.style.maxHeight = "";
            // Wait until the collapse transition has completed before hiding it.
            window.setTimeout(() => {
                if (!item.classList.contains("faq-open")) content.hidden = true;
            }, 300);
            if (icon) icon.textContent = "+";
        } else {
            content.hidden = false;
            item.classList.add("faq-open");
            button.setAttribute("aria-expanded", "true");
            content.style.maxHeight = content.scrollHeight + "px";
            if (icon) icon.textContent = "−";
        }
    });
});
