<?php
get_header();
$slug = get_post_field('post_name', get_queried_object_id());
$pages = array(
    'about' => 'about.html',
    'what-we-do' => 'what-we-do.html',
    'activities-and-initiatives' => 'activities-and-initiatives.html',
    'updates' => 'updates.html',
    'gallery' => 'gallery.html',
    'faqs' => 'faqs.html',
    'contact' => 'contact.html',
    'donate' => 'donate.html',
    'single-update' => 'single-update.html',
);
if (isset($pages[$slug])) {
    akanksha_render_static_page($pages[$slug]);
} else {
    while (have_posts()) : the_post();
        echo '<main class="max-w-7xl mx-auto px-6 py-16">';
        the_title('<h1>', '</h1>');
        the_content();
        echo '</main>';
    endwhile;
}
get_footer();
