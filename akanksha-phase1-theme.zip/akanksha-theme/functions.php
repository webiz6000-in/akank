<?php
/**
 * Akanksha Educational Foundation custom theme.
 * Phase 1 foundation: local assets, page rendering and navigation URL mapping.
 */
if (!defined('ABSPATH')) { exit; }

define('AKANKSHA_THEME_VERSION', '0.1.0');

function akanksha_enqueue_assets() {
    $uri = get_template_directory_uri();
    wp_enqueue_style('akanksha-tailwind-local', $uri . '/assets/css/tailwind-local.css', array(), AKANKSHA_THEME_VERSION);
    wp_enqueue_style('akanksha-fonts', $uri . '/assets/css/fonts.css', array('akanksha-tailwind-local'), AKANKSHA_THEME_VERSION);
    wp_enqueue_style('akanksha-custom', $uri . '/assets/css/style.css', array('akanksha-fonts'), AKANKSHA_THEME_VERSION);
    wp_enqueue_script('akanksha-site', $uri . '/assets/js/script.js', array(), AKANKSHA_THEME_VERSION, true);
}
add_action('wp_enqueue_scripts', 'akanksha_enqueue_assets');

/** Resolve the supplied static HTML navigation destinations to WordPress URLs. */
function akanksha_static_page_url($filename) {
    $map = array(
        'index.html' => home_url('/'),
        'about.html' => home_url('/about/'),
        'what-we-do.html' => home_url('/what-we-do/'),
        'activities-and-initiatives.html' => home_url('/activities-and-initiatives/'),
        'updates.html' => home_url('/updates/'),
        'gallery.html' => home_url('/gallery/'),
        'faqs.html' => home_url('/faqs/'),
        'contact.html' => home_url('/contact/'),
        'donate.html' => home_url('/donate/'),
        'donare.html' => home_url('/donate/'),
        'single-update.html' => home_url('/updates/sample-update/'),
    );
    return isset($map[$filename]) ? $map[$filename] : '';
}

/** Render the approved body markup while relocating local assets into the theme. */
function akanksha_render_static_page($filename) {
    $path = get_template_directory() . '/static-pages/' . basename($filename);
    if (!is_readable($path)) {
        echo '<p>' . esc_html__('Page source is not available.', 'akanksha') . '</p>';
        return;
    }
    $html = file_get_contents($path);
    if (!preg_match('/<body\\b[^>]*>(.*?)<\\/body>/is', $html, $matches)) {
        echo '<p>' . esc_html__('The supplied page has no readable body element.', 'akanksha') . '</p>';
        return;
    }
    $body = $matches[1];
    // Keep the approved desktop navigation destinations consistent on mobile too.
    // The supplied what-we-do.html mobile menu omits Activities & Initiatives.
    $body = preg_replace(
        '/(<div[^>]*id=[\"\']mobileMenu[\"\'][^>]*>.*?<a[^>]*href=[\"\']what-we-do\.html[\"\'][^>]*>.*?<\/a>)/is',
        '$1' . "\n<a href=\"activities-and-initiatives.html\">Activities &amp; Initiatives</a>",
        $body,
        1
    );
    $theme_uri = get_template_directory_uri();
    $body = preg_replace_callback('/\\b(src|href)=((["\\\'])((?:images|js)\\/[^"\\\']+|(?:index|about|what-we-do|activities-and-initiatives|updates|gallery|faqs|contact|donate|donare|single-update)\\.html)(["\\\']))/i', function ($m) use ($theme_uri) {
        $attribute = $m[1];
        $quote = $m[3];
        $target = $m[4];
        if (strpos($target, 'images/') === 0 || strpos($target, 'js/') === 0) {
            $url = $theme_uri . '/assets/' . $target;
        } else {
            $url = akanksha_static_page_url($target);
            if ($url === '') { return $m[0]; }
        }
        return $attribute . '=' . $quote . esc_url($url) . $quote;
    }, $body);
    // Assets are enqueued by WordPress; prevent duplicate page-level script loading.
    $body = preg_replace('/<script\\b[^>]*src=["\\\'][^"\\\']*js\\/script\\.js["\\\'][^>]*>\\s*<\\/script>/i', '', $body);
    echo $body; // Approved static HTML is trusted theme source; dynamic output is escaped separately.
}

function akanksha_register_theme_support() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
    register_nav_menus(array('primary' => __('Primary Navigation', 'akanksha')));
}
add_action('after_setup_theme', 'akanksha_register_theme_support');
