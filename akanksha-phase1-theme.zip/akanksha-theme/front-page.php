<?php get_header(); ?>
<?php akanksha_render_static_page('index.html'); ?>
<?php get_footer(); ?>
